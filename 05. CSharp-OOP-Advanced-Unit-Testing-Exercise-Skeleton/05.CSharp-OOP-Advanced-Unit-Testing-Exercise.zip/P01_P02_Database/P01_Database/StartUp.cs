﻿using System;

namespace P01_Database
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
        }
    }
}
