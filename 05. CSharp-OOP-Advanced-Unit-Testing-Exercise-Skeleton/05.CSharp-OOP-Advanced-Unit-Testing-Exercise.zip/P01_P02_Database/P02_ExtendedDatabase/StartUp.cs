﻿using System;

namespace P02_ExtendedDatabase
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
        }
    }
}
