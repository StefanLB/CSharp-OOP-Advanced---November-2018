﻿namespace StorageMaster.Entities.Vehicles
{
	public class Van : Vehicle
	{
		public Van()
			: base(capacity: 2)
		{
		}
	}
}