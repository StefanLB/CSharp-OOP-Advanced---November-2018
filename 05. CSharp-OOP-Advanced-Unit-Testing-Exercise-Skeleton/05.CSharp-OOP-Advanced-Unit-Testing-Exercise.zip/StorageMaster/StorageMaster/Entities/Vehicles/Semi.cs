﻿namespace StorageMaster.Entities.Vehicles
{
	public class Semi : Vehicle
	{
		public Semi()
			: base(capacity: 10)
		{
		}
	}
}