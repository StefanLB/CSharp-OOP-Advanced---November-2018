﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IteratorsAndComparators
{
    public interface ILibrary
    {
        List<Book> Books { get; }
    }
}
