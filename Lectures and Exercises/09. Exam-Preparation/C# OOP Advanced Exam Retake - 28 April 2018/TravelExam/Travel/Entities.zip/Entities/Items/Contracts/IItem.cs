﻿namespace Travel.Entities.Items.Contracts
{
	public interface IItem
	{
		int Value { get; }
	}
}
