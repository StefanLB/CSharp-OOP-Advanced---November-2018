﻿namespace Travel.Entities.Items
{
	public class Jewelery : Item
	{
        private const int JewelryValue = 300;
		public Jewelery()
			: base(JewelryValue)
		{
		}
	}
}