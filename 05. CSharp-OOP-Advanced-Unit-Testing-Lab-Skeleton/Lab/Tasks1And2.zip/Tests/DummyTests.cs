﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace Tests
{
    [TestFixture]
    public class DummyTests
    {
        [Test]
        public void DummyLosesHealthAfterAttack()
        {
            //Arrange
            Dummy dummy = new Dummy(20, 10);

            //Act
            dummy.TakeAttack(5);

            //Assert
            Assert.That(dummy.Health, Is.EqualTo(15));
        }

        [Test]
        public void DeadDummyThrowsExceptionIfAttacked()
        {
            //Arrange
            Dummy dummy = new Dummy(5, 10);

            //Act
            dummy.TakeAttack(5);

            //Assert
            Assert.That(()=>dummy.TakeAttack(5),
                Throws.InvalidOperationException
                .With.Message.EqualTo("Dummy is dead."));
        }

        [Test]
        public void DeadDummyCanGiveXp()
        {
            //Arrange
            Dummy dummy = new Dummy(5, 10);

            //Act
            dummy.TakeAttack(5);

            //Assert
            Assert.That(dummy.GiveExperience(), Is.EqualTo(10));
        }

        [Test]
        public void AliveDummyCantGiveXp()
        {
            //Arrange
            Dummy dummy = new Dummy(5, 10);

            //Act
            dummy.TakeAttack(2);

            //Assert
            Assert.That(() => dummy.GiveExperience(),
                Throws.InvalidOperationException
                .With.Message.EqualTo("Target is not dead."));
        }
    }
}
