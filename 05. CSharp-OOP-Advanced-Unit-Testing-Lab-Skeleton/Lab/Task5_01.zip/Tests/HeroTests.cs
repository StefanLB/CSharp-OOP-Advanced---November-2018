﻿using NUnit.Framework;
using Skeleton;
using Skeleton.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace Tests
{
    [TestFixture]
    public class HeroTests
    {
        //Create HeroTests class and test gaining XP functionality 
        //by faking Weapon and Target classes

        [Test]
        public void TestHeroGainXp()
        {
            IWeapon fakeWeapon = new FakeWeapon();
            ITarget fakeTarget = new FakeTarget();

            Hero hero = new Hero("Pesho", fakeWeapon);

            hero.Attack(fakeTarget);

            var actualResult = hero.Experience;
            var expectedResult = 10;

            Assert.AreEqual(expectedResult, actualResult);

        }
    }
}
