﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P07_InfernoInfinity.Enums
{
    public enum RarityLevel
    {
        Common = 1,
        Uncommon = 2,
        Rare = 3,
        Epic = 5
    }
}
