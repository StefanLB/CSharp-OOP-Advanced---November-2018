﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P07_InfernoInfinity.Enums
{
    public enum Clarity
    {
        Chipped = 1,
        Regular = 2,
        Perfect = 5,
        Flawless = 10
    }
}
