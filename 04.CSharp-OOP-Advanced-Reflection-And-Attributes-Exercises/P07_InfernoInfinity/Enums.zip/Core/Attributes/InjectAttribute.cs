﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P07_InfernoInfinity.Core.Attributes
{
    public class InjectAttribute : Attribute
    {
    }
}
