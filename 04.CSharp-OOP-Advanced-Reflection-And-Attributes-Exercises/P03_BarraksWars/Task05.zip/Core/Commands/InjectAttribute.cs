﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03BarraksWars.Core.Commands
{
    class InjectAttribute : Attribute
    {
    }
}
