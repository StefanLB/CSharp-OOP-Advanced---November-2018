﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P08_CreateCustomClassAttribute
{
    [Custom("Pesho", 3, "Used for C# OOP Advanced Course - Enumerations and Attributes.", "Pesho", "Svetlio")]
    public abstract class Weapon
    {

    }
}
