﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.ListIterator
{
    public class ListyIterator<T>
    {
        private List<T> elements;
        private int currentIndex;

        public ListyIterator(params T[] elements)
        {
            this.elements = new List<T>(elements);
        }

        public bool Move()
        {
            if (++currentIndex<elements.Count)
            {
                return true;
            }
            currentIndex--;
            return false;
        }

        public void Print()
        {
            if (elements.Count==0)
            {
                throw new InvalidOperationException("Invalid Operation!");
            }
            Console.WriteLine(elements[currentIndex]);
        }

        public bool HasNext()
        {
            if ((currentIndex+1)<elements.Count)
            {
                return true;
            }
            return false;
        }
    }
}
